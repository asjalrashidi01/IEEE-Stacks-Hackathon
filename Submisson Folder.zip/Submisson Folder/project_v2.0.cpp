#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <windows.h>

using namespace std;

/** FUNCTIONS Calls **/

void selling_prompt();
void print_list();
void menu_prompt();
int buying_prompt();
void wallet_prompt();
void recall_order(int order);
/**********************/

int main()
{
    menu_prompt();
}


/** FUNCTIONS **/
/**********************/

void menu_prompt()
{
	int menu_choice = 0;
	cout << "Welcome to Sidemen SNKR" << endl;
	cout << "You can either buy or sell sneakers on this platform." << endl;
	cout << "Press 1 to buy sneakers." << endl;
	cout << "Press 2 to sell sneakers." << endl;
	cout << "Press 3 to view your SNKR wallet." << endl;
	cout << "Choice: ";
	cin >> menu_choice;
	cin.ignore();
	cout << endl;

    system("CLS");

	int order;

	if (menu_choice == 1)
	{
		order=buying_prompt();
	    cout<<"You have bought the following: "<<endl<<endl;
		
	}
	else if (menu_choice == 2)
	{
		selling_prompt();
	}
	else if (menu_choice == 3)
	{
		wallet_prompt();
	}
	else
	{
		cout << "Please enter a valid number" << endl;
		menu_prompt();
	}

	recall_order(order);
}

int buying_prompt()
{
    print_list();

    int snk_ord = 0;
    int counter = 1;
    int i = 0;
    //int order[20]={0};

    cout << "Enter sneaker number to buy (0 to exit to previous menu): ";
    cin >> snk_ord;
    cin.ignore();

    if(snk_ord==0)
    {
    	system("CLS");
        menu_prompt();
    }

    system("CLS");

    return(snk_ord);
    
    
}

void print_list()
{
	cout << "The sneakers available for purchase are as follows:" << endl;
	cout << endl;

	fstream sneaker_list;

	sneaker_list.open("Sneaker List.txt");

	string finder;
	int counter[20] = {};
	int i = 0;

	do
	{
		sneaker_list >> finder;
		if (finder == "Seller:")
		{
			counter[i]=i+1;
			i++;
		}
	}
	while (!sneaker_list.eof());

	sneaker_list.close();

	sneaker_list.open("Sneaker List.txt");

    int j = 0;
	while(!sneaker_list.eof())
	{
		string temp;

		getline(sneaker_list, temp);

		if(temp == ".Sneaker")
        {
            cout << temp <<" "<<counter[j]<< endl;

            j++;
        }
        else
        {
           cout << temp << endl;
        }


	}

	sneaker_list.close();

}


void selling_prompt()
{

	fstream snk_dat;

    snk_dat.open("Sneaker List.txt",snk_dat.app);

    string snk_name="";
    string snk_size="";
    string snk_price="";
    string slr_name="";




    cout<<"Enter Sneaker Name (0 to exit to previous menu): ";                  //Taking inputs from the user
    getline(cin,snk_name);
    
    if(snk_name == "0")
    {
    	system("CLS");
        menu_prompt();
    }
    
    cout<<"Enter Sneaker Size: ";
    getline(cin,snk_size);
    cout<<"Enter Sneaker Price: SNKR ";
    getline(cin,snk_price);
    cout<<"Enter Your Name: ";
    getline(cin,slr_name);


    snk_dat<<"\n"<<".Sneaker"<<"\n";                   //Writing in the text file
    snk_dat<<"\n"<<"Name: "<<snk_name<<"\n";
    snk_dat<<"Size: "<<snk_size<<"\n";
    snk_dat<<"Price: SNKR "<<snk_price<<"\n";
    snk_dat<<"Seller: "<<slr_name<<"\n";

    snk_dat.close();


}

void recall_order(int order)
{
    int n= order;

    fstream sneaker_list;

	sneaker_list.open("Sneaker List.txt");

	//string finder;
	int counter=0;


	while (!sneaker_list.eof())
	{
        string temp;
        getline(sneaker_list,temp);
        counter++;
	}
    //cout<<counter;
    sneaker_list.close();
    sneaker_list.open("Sneaker List.txt");

    for(int i=1; i<=counter;i++)
    {
        string temp;
        getline(sneaker_list, temp);
        //cout<<temp;

        if(i>=((7*(n-1))+3) && i<=((7*(n-1))+5))
        {
            cout<<temp<<endl;
        }
    }


	sneaker_list.close();
}

void wallet_prompt()
{
	string SNKR_id;
	cout << "Enter your SNKR ID (0 to exit to previous menu): ";
	cin >> SNKR_id;
	
	if(SNKR_id == "0")
    {
    	system("CLS");
        menu_prompt();
    }

	fstream ledger;

	ledger.open("SNKR Ledger.txt");

	bool id_check = 1;
	int counter = 0;

	string temp_check = "SNKR ID: " + SNKR_id;

	while (id_check)
	{
		string check;
		getline(ledger, check);
		counter++;
		if (check == temp_check)
		{
			break;
		}
	}

	for (int i = 1; i < counter + 4; i++)
	{
		string temp;
		getline(ledger, temp);
		if (i > counter)
		{
			cout << temp << endl;;
		}
	}

	ledger.close();
}










